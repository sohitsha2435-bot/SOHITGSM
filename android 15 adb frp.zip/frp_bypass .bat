@echo off
REM ============================================================
REM  SohitGSM - FRP Tool (via ADB) - Vivo / Android
REM  Menu-based edition - English only - with visual colors
REM  Requirement: USB Debugging / ADB enabled and device connected
REM  Note: No operation runs until device ownership is verified
REM ============================================================
chcp 65001 >nul
setlocal EnableDelayedExpansion
title SohitGSM - FRP Tool

REM --- Build the ESC character for ANSI colors (Windows 10+) ---
for /f %%a in ('echo prompt $E ^| cmd') do set "E=%%a"

REM --- Color palette ---
set "C_RESET=%E%[0m"
set "C_TITLE=%E%[1;96m"
set "C_FRAME=%E%[38;5;33m"
set "C_NUM=%E%[1;93m"
set "C_TXT=%E%[0;97m"
set "C_OK=%E%[1;92m"
set "C_BAD=%E%[1;91m"
set "C_WARN=%E%[1;93m"
set "C_INFO=%E%[1;96m"
set "C_FOOT=%E%[1;95m"
set "C_DIM=%E%[2;37m"

REM --- Ownership flag (gate). Must be YES before any action runs ---
set "OWNER=NO"

REM --- Check that adb exists before showing the menu ---
where adb >nul 2>&1
if errorlevel 1 (
    cls
    echo %C_BAD%[X] ERROR: adb not found in PATH.%C_RESET%
    echo %C_TXT%    Put adb.exe in this folder, or add it to PATH.%C_RESET%
    echo.
    pause
    exit /b 1
)

REM ============================================================
REM  ANIMATION: Boot / loading screen
REM ============================================================
:BOOT
cls
echo.
echo %C_FRAME%   ============================================================%C_RESET%
echo %C_TITLE%              S O H I T G S M   -   F R P   T O O L%C_RESET%
echo %C_FRAME%   ============================================================%C_RESET%
echo.
call :LOADING "Initializing ADB server" 25
call :LOADING "Loading modules" 25
call :LOADING "Preparing interface" 25
echo.
echo %C_OK%   [OK] Ready.%C_RESET%
timeout /t 1 >nul
goto MENU

REM ============================================================
REM  Loading bar animation  (call :LOADING "text" steps)
REM ============================================================
:LOADING
set "LTEXT=%~1"
set /a LSTEPS=%~2
<nul set /p "=%C_TXT%   %LTEXT% ... %C_RESET%["
for /l %%i in (1,1,%LSTEPS%) do (
    <nul set /p "=%C_OK%#%C_RESET%"
    ping -n 1 -w 15 127.0.0.1 >nul
)
echo] %C_OK%OK%C_RESET%
exit /b 0

REM ============================================================
REM  Spinner animation  (call :SPIN "text" iterations)
REM ============================================================
:SPIN
set "STEXT=%~1"
set /a SITER=%~2
<nul set /p "=%C_INFO%   %STEXT% %C_RESET%"
for /l %%i in (1,1,%SITER%) do (
    <nul set /p "=%C_INFO%|%C_RESET%"
    ping -n 1 -w 40 127.0.0.1 >nul
    <nul set /p "=%C_RESET%\%C_RESET%"
    ping -n 1 -w 40 127.0.0.1 >nul
    <nul set /p "=%C_RESET%-%C_RESET%"
    ping -n 1 -w 40 127.0.0.1 >nul
    <nul set /p "=%C_RESET%/%C_RESET%"
    ping -n 1 -w 40 127.0.0.1 >nul
)
echo %C_OK%done%C_RESET%
exit /b 0

REM ============================================================
REM  Typewriter effect  (call :TYPE "text")
REM ============================================================
:TYPE
set "TTEXT=%~1"
set "TOUT="
:TYPER_LOOP
if defined TTEXT (
    set "TCH=!TTEXT:~0,1!"
    set "TTEXT=!TTEXT:~1!"
    set "TOUT=!TOUT!!TCH!"
    <nul set /p "=!TOUT!"
    ping -n 1 -w 20 127.0.0.1 >nul
    goto TYPER_LOOP
)
echo.
exit /b 0

:MENU
cls
echo.
echo %C_FRAME%   ============================================================%C_RESET%
echo %C_FRAME%   ^|^|%C_RESET%        %C_TITLE%S O H I T G S M%C_RESET%                      %C_FRAME%^|^|%C_RESET%
echo %C_FRAME%   ^|^|%C_RESET%              %C_INFO%FRP Tool  -  via ADB%C_RESET%                    %C_FRAME%^|^|%C_RESET%
echo %C_FRAME%   ============================================================%C_RESET%
echo.
if /i "!OWNER!"=="YES" (
    echo    %C_TXT%Ownership verified:%C_RESET%  %C_OK%YES%C_RESET%
) else (
    echo    %C_TXT%Ownership verified:%C_RESET%  %C_BAD%NO%C_RESET%
)
echo %C_DIM%   ------------------------------------------------------------%C_RESET%
echo.
echo     %C_NUM%[1]%C_RESET%  %C_TXT%Check device info%C_RESET%
echo     %C_NUM%[2]%C_RESET%  %C_TXT%Disable Setup Wizard%C_RESET%
echo     %C_NUM%[3]%C_RESET%  %C_TXT%Mark device provisioned%C_RESET%
echo     %C_NUM%[4]%C_RESET%  %C_TXT%Open account / login screen%C_RESET%
echo     %C_NUM%[5]%C_RESET%  %C_TXT%Remove lock files %C_WARN%(ROOT)%C_RESET%
echo     %C_NUM%[6]%C_RESET%  %C_OK%FULL AUTO (steps 2-3-4)%C_RESET%
echo     %C_NUM%[7]%C_RESET%  %C_TXT%Reboot device%C_RESET%
echo.
echo     %C_INFO%[V]%C_RESET%  %C_TXT%Verify ownership%C_RESET%
echo     %C_BAD%[0]%C_RESET%  %C_TXT%Exit%C_RESET%
echo.
echo %C_FRAME%   ============================================================%C_RESET%
echo %C_FOOT%   SohitGSM - wa.me/919650469570 - t.me/SohitGSM%C_RESET%
echo %C_FRAME%   ============================================================%C_RESET%
echo.
set /p CH="%C_INFO%   Select an option: %C_RESET%"

if /i "!CH!"=="1" goto DEVINFO
if /i "!CH!"=="2" goto DISABLE_SW
if /i "!CH!"=="3" goto PROVISION
if /i "!CH!"=="4" goto LOGIN
if /i "!CH!"=="5" goto ROOT_LOCK
if /i "!CH!"=="6" goto FULLAUTO
if /i "!CH!"=="7" goto REBOOT
if /i "!CH!"=="V" goto VERIFY
if /i "!CH!"=="0" goto END
goto MENU

REM ============================================================
REM  Device connection check (shared by all actions)
REM ============================================================
:CHECK_DEVICE
call :SPIN "Checking device connection" 2
adb start-server >nul 2>&1
set DEV=0
for /f "skip=1 tokens=1,2" %%a in ('adb devices') do (
    if "%%b"=="device" set /a DEV+=1
)
if !DEV! EQU 0 (
    echo %C_BAD%[X] No authorized device detected.%C_RESET%
    echo %C_TXT%    - Check the USB cable%C_RESET%
    echo %C_TXT%    - Enable USB Debugging and accept the RSA prompt on screen%C_RESET%
    echo.
    exit /b 1
)
echo %C_OK%[OK] Device(s) connected: !DEV!%C_RESET%
exit /b 0

REM ============================================================
REM  Ownership gate (shared by all actions)
REM ============================================================
:REQUIRE_OWNER
if /i "!OWNER!"=="YES" exit /b 0
echo.
echo %C_BAD%[!] This action is blocked until ownership is verified.%C_RESET%
echo %C_TXT%    Use option [V] first.%C_RESET%
echo.
pause
exit /b 1

REM ============================================================
REM  [V] Verify ownership
REM ============================================================
:VERIFY
cls
echo.
echo %C_FRAME%   ============================================================%C_RESET%
echo %C_TITLE%   Verify device ownership%C_RESET%
echo %C_FRAME%   ============================================================%C_RESET%
echo.
echo %C_TXT%   Confirm you have verified that the device belongs to the%C_RESET%
echo %C_TXT%   customer (proof of purchase / ID / invoice as per policy).%C_RESET%
echo.
set /p OK="%C_WARN%   Has ownership been verified? (y/n): %C_RESET%"
if /i "!OK!"=="y" (
    set "OWNER=YES"
    call :SPIN "Verifying" 1
    echo %C_OK%   [OK] Ownership marked as VERIFIED.%C_RESET%
) else (
    set "OWNER=NO"
    echo.
    echo %C_BAD%   [X] Ownership NOT verified. Actions remain blocked.%C_RESET%
)
echo.
pause
goto MENU

REM ============================================================
REM  [1] Device info
REM ============================================================
:DEVINFO
cls
echo.
call :CHECK_DEVICE || (pause & goto MENU)
echo.
echo %C_INFO%[*] Device info%C_RESET%
echo %C_TXT%   Model   :%C_RESET%
adb shell getprop ro.product.model
echo %C_TXT%   Android :%C_RESET%
adb shell getprop ro.build.version.release
echo %C_TXT%   Security:%C_RESET%
adb shell getprop ro.build.version.security_patch
echo.
pause
goto MENU

REM ============================================================
REM  [2] Disable Setup Wizard / provision packages
REM ============================================================
:DISABLE_SW
cls
echo.
call :REQUIRE_OWNER || goto MENU
call :CHECK_DEVICE || (pause & goto MENU)
echo.
call :SPIN "Disabling Setup Wizard packages" 2
adb shell pm disable-user --user 0 com.google.android.setupwizard  2>nul
adb shell pm disable-user --user 0 com.android.provision            2>nul
adb shell pm disable-user --user 0 com.google.android.gms.setup     2>nul
echo %C_OK%   done.%C_RESET%
echo.
pause
goto MENU

REM ============================================================
REM  [3] Mark device as provisioned
REM ============================================================
:PROVISION
cls
echo.
call :REQUIRE_OWNER || goto MENU
call :CHECK_DEVICE || (pause & goto MENU)
echo.
call :SPIN "Marking device as provisioned" 2
REM Method 1: settings put
adb shell settings put global device_provisioned 1       2>nul
adb shell settings put secure user_setup_complete 1      2>nul
adb shell settings put secure user_setup_complete 1 --user 0 2>nul
REM Fallback: content insert (sometimes needed on Android 14/15 when settings are locked)
adb shell content insert --uri content://settings/global --bind name:s:device_provisioned --bind value:s:1 2>nul
adb shell content insert --uri content://settings/secure --bind name:s:user_setup_complete --bind value:s:1 2>nul
echo %C_OK%   done.%C_RESET%
echo.
pause
goto MENU

REM ============================================================
REM  [4] Open login / settings screens
REM ============================================================
:LOGIN
cls
echo.
call :REQUIRE_OWNER || goto MENU
call :CHECK_DEVICE || (pause & goto MENU)
echo.
call :SPIN "Launching login / settings screens" 2
adb shell am start -n com.google.android.gsf.login/com.google.android.gsf.login.LoginActivity 2>nul
timeout /t 2 >nul
adb shell am start -a android.settings.ADD_ACCOUNT_SETTINGS 2>nul
timeout /t 2 >nul
adb shell am start -a android.settings.SETTINGS 2>nul
echo %C_OK%   done. Check the device screen now.%C_RESET%
echo.
pause
goto MENU

REM ============================================================
REM  [5] Remove lock files (needs ROOT)
REM ============================================================
:ROOT_LOCK
cls
echo.
call :REQUIRE_OWNER || goto MENU
call :CHECK_DEVICE || (pause & goto MENU)
echo %C_FRAME%   ============================================================%C_RESET%
echo %C_WARN%   [!] Remove lock files - requires ROOT%C_RESET%
echo %C_TXT%       On a normal (non-rooted) device this step will fail.%C_RESET%
echo %C_FRAME%   ============================================================%C_RESET%
echo.
set /p DOROOT="%C_WARN%   Try removing lock files? (y/n): %C_RESET%"
if /i "!DOROOT!"=="y" (
    call :SPIN "Removing lock / account files" 2
    adb shell rm /data/system/locksettings.db*            2>nul
    adb shell rm /data/system/gatekeeper.password.key     2>nul
    adb shell rm /data/system/gatekeeper.pattern.key      2>nul
    adb shell rm /data/system/gatekeeper.gesture.key      2>nul
    adb shell rm /data/system/users/0/accounts.db*        2>nul
    adb shell rm /data/system/users/0/accounts_ce.db*     2>nul
    echo %C_OK%   done ^(ignore "Permission denied" if the device is not rooted^).%C_RESET%
)
echo.
pause
goto MENU

REM ============================================================
REM  [6] FULL AUTO (steps 2 - 3 - 4)
REM ============================================================
:FULLAUTO
cls
echo.
call :REQUIRE_OWNER || goto MENU
call :CHECK_DEVICE || (pause & goto MENU)
echo %C_TITLE%[*] FULL AUTO: Disable Setup Wizard + Provision + Login%C_RESET%
echo.
call :LOADING "(1/3) Disabling Setup Wizard packages" 20
adb shell pm disable-user --user 0 com.google.android.setupwizard  2>nul
adb shell pm disable-user --user 0 com.android.provision            2>nul
adb shell pm disable-user --user 0 com.google.android.gms.setup     2>nul
echo.
call :LOADING "(2/3) Marking device as provisioned" 20
adb shell settings put global device_provisioned 1       2>nul
adb shell settings put secure user_setup_complete 1      2>nul
adb shell settings put secure user_setup_complete 1 --user 0 2>nul
adb shell content insert --uri content://settings/global --bind name:s:device_provisioned --bind value:s:1 2>nul
adb shell content insert --uri content://settings/secure --bind name:s:user_setup_complete --bind value:s:1 2>nul
echo.
call :LOADING "(3/3) Launching login / settings screens" 20
adb shell am start -n com.google.android.gsf.login/com.google.android.gsf.login.LoginActivity 2>nul
timeout /t 2 >nul
adb shell am start -a android.settings.ADD_ACCOUNT_SETTINGS 2>nul
timeout /t 2 >nul
adb shell am start -a android.settings.SETTINGS 2>nul
echo.
echo %C_FRAME%   ============================================================%C_RESET%
echo %C_OK%   DONE! Try adding a new Google account from Settings.%C_RESET%
echo %C_TXT%   If it does not work: reboot and try again.%C_RESET%
echo %C_FRAME%   ============================================================%C_RESET%
echo.
pause
goto MENU

REM ============================================================
REM  [7] Reboot device
REM ============================================================
:REBOOT
cls
echo.
call :CHECK_DEVICE || (pause & goto MENU)
echo.
set /p RB="%C_WARN%   Reboot the device now? (y/n): %C_RESET%"
if /i "!RB!"=="y" adb reboot
echo.
pause
goto MENU

REM ============================================================
REM  [0] Exit
REM ============================================================
:END
cls
echo.
echo %C_FRAME%   ============================================================%C_RESET%
call :TYPE "   Goodbye from SohitGSM ..."
echo %C_FOOT%   SohitGSM  -  wa.me/919650469570  -  t.me/SohitGSM%C_RESET%
echo %C_FRAME%   ============================================================%C_RESET%
echo.
timeout /t 2 >nul
endlocal
exit /b 0