@echo off
cd /d %~dp0

cls
echo *************************************
echo *************Information*************
echo *************************************
echo Dirver Installer v1.0

for /f %%i in ('ver^|%systemroot%\system32\find.exe "5.0."') do echo Win NT && set osrecognized=2
for /f %%i in ('ver^|%systemroot%\system32\find.exe "5.1."') do echo Win XP && set osrecognized=2
for /f %%i in ('ver^|%systemroot%\system32\find.exe "5.2."') do echo Win 2003 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.0."') do echo Win Vista && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.1."') do echo Win 7 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.2."') do echo Win 8 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.3."') do echo Win 8 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.4."') do echo Win 8 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "10.0."') do echo Win 10 && set osrecognized=1

if not defined osrecognized goto NotSupport

@set PLATFORM=x86
@if "%PROCESSOR_IDENTIFIER:~0,3%"=="x86" (set PLATFORM=/SmartPhoneDriver/x86) ^
else (set PLATFORM=/SmartPhoneDriver/x64)

@set PLATFORM=%cd%%PLATFORM%

echo %PLATFORM%
@echo.
@echo.

if %osrecognized% EQU 1 goto newSystem

echo *******************************************
echo **********Install mtp inf******************
echo *******************************************
"%PLATFORM%/dpinst.exe" /PATH "%cd%/SmartPhoneDriver/windowsXP" /F /LM /SW /A
echo Install complete!
@echo.
@echo.

:newSystem

echo *******************************************
echo **********Install adb inf******************
echo *******************************************
"%PLATFORM%/dpinst.exe" /PATH "%PLATFORM%\adb infs" /F /LM /SW /A
echo Install complete!
@echo.
@echo.


echo *******************************************
echo **********Install SP unsigned inf**********
echo *******************************************
"%PLATFORM%/dpinst.exe" /PATH "%PLATFORM%\Unsigned infs" /F /LM /SW /A
echo Install complete!
@echo.
@echo.


echo *****************************************
echo **********Install SP Qcom inf************
echo *****************************************
"%PLATFORM%/dpinst.exe" /PATH "%PLATFORM%\WindowsQcom" /F /LM /SW /A
echo Install complete!
@echo.
@echo.


echo *****************************************
echo **********Install Fastboot inf***********
echo *****************************************
"%PLATFORM%/dpinst.exe" /PATH "%PLATFORM%\fastboot_driver" /F /LM /SW /A
echo Install complete!
@echo.
@echo.

goto end

:NotSupport
echo Do Not support Win NT earlier version

:end
pause