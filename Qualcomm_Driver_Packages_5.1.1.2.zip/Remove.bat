@echo off
cd /d %~dp0
cls
echo *************************************
echo *************Information*************
echo *************************************
echo Dirver Installer v1.0

for /f %%i in ('ver^|%systemroot%\system32\find.exe "5.0."') do echo Win NT && set osrecognized=2
for /f %%i in ('ver^|%systemroot%\system32\find.exe "5.1."') do echo Win XP && set osrecognized=2
for /f %%i in ('ver^|%systemroot%\system32\find.exe "5.2."') do echo Win 2003 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.0."') do echo Win Vista && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.1."') do echo Win 7 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.2."') do echo Win 8 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.3."') do echo Win 8 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "6.4."') do echo Win 8 && set osrecognized=1
for /f %%i in ('ver^|%systemroot%\system32\find.exe "10.0."') do echo Win 10 && set osrecognized=1

if not defined osrecognized goto NotSupport

@set PLATFORM=x86
@if "%PROCESSOR_IDENTIFIER:~0,3%"=="x86" (set PLATFORM=/SmartPhoneDriver/x86) ^
else (set PLATFORM=/SmartPhoneDriver/x64)

@set PLATFORM=%cd%%PLATFORM%

echo %PLATFORM%
@echo.
@echo.

if %osrecognized% EQU 1 goto newSystem

echo *******************************************
echo **********Uninstall mtp inf****************
echo *******************************************
"%PLATFORM%/DPInst.exe" /U "%cd%/SmartPhoneDriver/windowsXP\wpdmtp.inf" /SW /D
echo Uninstall complete!
@echo.
@echo.

:newSystem

echo *********************************************
echo **********Uninstall SP adb inf***************
echo *********************************************
"%PLATFORM%/DPInst.exe" /U "%PLATFORM%\adb infs\android_winusb.inf" /SW /D
echo Uninstall complete!
@echo.
@echo.


echo *********************************************
echo **********Uninstall SP unsigned inf**********
echo *********************************************
"%PLATFORM%/DPInst.exe" /U "%PLATFORM%\Unsigned infs\cdc-acm.inf" /SW /D
"%PLATFORM%/DPInst.exe" /U "%PLATFORM%\Unsigned infs\tetherxp.inf" /SW /D
echo Uninstall complete!
@echo.
@echo.


echo *******************************************
echo **********Uninstall SP signed inf**********
echo *******************************************
"%PLATFORM%/DPInst.exe" /U "%PLATFORM%\Infs\usbvcom.inf" /SW /D
"%PLATFORM%/DPInst.exe" /U "%PLATFORM%\Infs\usbvcom_brom.inf" /SW /D
echo Uninstall complete!
@echo.
@echo.


echo *****************************************
echo **********Uninstall SP Qcom inf**********
echo *****************************************
"%PLATFORM%/DPInst.exe" /U "%PLATFORM%\WindowsQcom\qcmdm.inf" /SW /D
"%PLATFORM%/DPInst.exe" /U "%PLATFORM%\WindowsQcom\qcser.inf" /SW /D
echo Uninstall complete!
@echo.
@echo.


echo *****************************************
echo **********Uninstall SP Fastboot inf******
echo *****************************************
"%PLATFORM%/DPInst.exe" /U "%PLATFORM%\fastboot_driver\android_usb.inf" /SW /D
echo Uninstall complete!
@echo.
@echo.

goto end

:NotSupport
echo Do Not support Win NT earlier version

:end
pause